using Microsoft.AspNetCore.Mvc;

namespace QuickCartMVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
