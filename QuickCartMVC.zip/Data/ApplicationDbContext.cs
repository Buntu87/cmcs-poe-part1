using Microsoft.EntityFrameworkCore;
using QuickCartMVC.Models;

namespace QuickCartMVC.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<ClaimItem> Claims { get; set; } = null!;
    }
}
