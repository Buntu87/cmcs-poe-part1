using System.ComponentModel.DataAnnotations;

namespace QuickCartMVC.Models
{
    public class ClaimItem
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Claim Title")]
        public string Title { get; set; } = string.Empty;

        [Display(Name = "Description")]
        public string? Description { get; set; }

        [Display(Name = "Amount (ZAR)")]
        [DataType(DataType.Currency)]
        public decimal Amount { get; set; }

        [Display(Name = "Submitted On")]
        public DateTime SubmittedOn { get; set; } = DateTime.UtcNow;

        [Display(Name = "Status")]
        public string Status { get; set; } = "Pending";
    }
}
