# QuickCartMVC - Contract Monthly Claim System (Prototype)

This is a minimal ASP.NET Core MVC prototype to fulfil the POE assignment requirements:
- MVC web interface (instead of WPF)
- In-memory database to demonstrate data model and CRUD operations
- Simple, user-friendly UI

Reference used for design guidance: *C# 10 and .NET 6 - Modern Cross-Platform Development (Pro)* — adapted examples and patterns to suit the coursework.

## Run locally

1. Ensure you have .NET 7 SDK installed (or change TargetFramework in csproj to net6.0 if using .NET 6).
2. From the project folder:
   ```bash
   dotnet restore
   dotnet run
   ```
3. Open browser at `https://localhost:5001` or `http://localhost:5000`.

