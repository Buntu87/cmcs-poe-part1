using System.Windows;

namespace CMCS
{
    public partial class ClaimApprovalWindow : Window
    {
        public ClaimApprovalWindow()
        {
            InitializeComponent();
        }
    }
}