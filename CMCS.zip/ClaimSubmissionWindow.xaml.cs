using System.Windows;

namespace CMCS
{
    public partial class ClaimSubmissionWindow : Window
    {
        public ClaimSubmissionWindow()
        {
            InitializeComponent();
        }
    }
}