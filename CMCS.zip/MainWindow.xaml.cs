using System.Windows;

namespace CMCS
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.ShowDialog();
        }

        private void btnClaimSubmission_Click(object sender, RoutedEventArgs e)
        {
            ClaimSubmissionWindow claimSubmissionWindow = new ClaimSubmissionWindow();
            claimSubmissionWindow.ShowDialog();
        }

        private void btnClaimApproval_Click(object sender, RoutedEventArgs e)
        {
            ClaimApprovalWindow claimApprovalWindow = new ClaimApprovalWindow();
            claimApprovalWindow.ShowDialog();
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}