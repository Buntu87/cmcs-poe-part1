using System.Windows;

namespace CMCS
{
    public partial class App : Application
    {
    }
}