using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuickCartMVC.Data;
using QuickCartMVC.Models;

namespace QuickCartMVC.Controllers
{
    public class ClaimsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClaimsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // --- OPTIONAL: Manual Stored Procedure Loader ---
        public IActionResult LoadAll()
        {
            List<ClaimItem> claimItems = new List<ClaimItem>();

            try
            {
                // Must exist in ApplicationDbContext
                claimItems = _context.GetAll();
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
            }

            return View("Index", claimItems);
        }

        // --- GET: /Claims ---
        public async Task<IActionResult> Index()
        {
            var claims = await _context.Claims
                .OrderByDescending(c => c.SubmittedOn)
                .ToListAsync();

            return View(claims);
        }

        // --- GET: /Claims/Details/5 ---
        public async Task<IActionResult> Details(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null) return NotFound();

            return View(claim);
        }

        // --- GET: /Claims/Create ---
        public IActionResult Create() => View();

        // --- POST: /Claims/Create ---
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ClaimItem model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Optional Stored Procedure Insert
            bool result = _context.Insert(model);

            if (!result)
            {
                TempData["ErrorMessage"] = "Unable to save the data";
                return View(model);
            }

            // If using EF Core, uncomment:
            // _context.Add(model);
            // await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Claim created successfully!";
            return RedirectToAction(nameof(Index));
        }

        // --- GET: /Claims/Edit/5 ---
        public async Task<IActionResult> Edit(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null) return NotFound();

            return View(claim);
        }

        // --- POST: /Claims/Edit/5 ---
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ClaimItem claim)
        {
            if (id != claim.Id)
                return BadRequest();

            if (!ModelState.IsValid)
                return View(claim);

            try
            {
                _context.Update(claim);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Claims.Any(c => c.Id == id))
                    return NotFound();

                throw;
            }

            TempData["SuccessMessage"] = "Claim updated successfully!";
            return RedirectToAction(nameof(Index));
        }

        // --- GET: /Claims/Delete/5 ---
        public async Task<IActionResult> Delete(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null) return NotFound();

            return View(claim);
        }

        // --- POST: /Claims/DeleteConfirmed ---
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var claim = await _context.Claims.FindAsync(id);

            if (claim != null)
            {
                _context.Claims.Remove(claim);
                await _context.SaveChangesAsync();
            }

            TempData["SuccessMessage"] = "Claim deleted successfully!";
            return RedirectToAction(nameof(Index));
        }
    }
}


