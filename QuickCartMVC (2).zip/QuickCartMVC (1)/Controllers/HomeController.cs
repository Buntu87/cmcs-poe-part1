using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace QuickCartMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // GET: /
        public IActionResult Index()
        {
            _logger.LogInformation("Home page loaded at {Time}", DateTime.UtcNow);
            return View();
        }

        // Optional: About page
        public IActionResult About()
        {
            return View();
        }

        // Optional: Error Handler (recommended for current ASP.NET Core versions)
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View();
        }
    }
}


