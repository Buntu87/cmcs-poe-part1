﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace QuickCartMVC.Models
{
    public class ClaimItem
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Claim Title")]
        public string Title { get; set; } = string.Empty;

        [Display(Name = "Description")]
        public string? Description { get; set; }

        [Display(Name = "Amount (ZAR)")]
        [DataType(DataType.Currency)]
        [Range(0.01, 100000, ErrorMessage = "Amount must be greater than 0.")]
        public decimal Amount { get; set; }

        [Display(Name = "Submitted On")]
        public DateTime SubmittedOn { get; set; } = DateTime.UtcNow;

        [Display(Name = "Status")]
        public string Status { get; set; } = "Pending";

        // ---------------------------
        // 📁 FILE UPLOAD PROPERTIES
        // ---------------------------

        [Display(Name = "Supporting Document")]
        public string? FileName { get; set; }  // Stores file name or file path

        [Display(Name = "Upload File")]
        [AllowedExtensions(new string[] { ".pdf", ".docx", ".xlsx" })]
        [MaxFileSize(5 * 1024 * 1024)] // 5 MB limit
        public IFormFile? UploadedFile { get; set; }
    }

    // ---------------------------
    // 📌 CUSTOM VALIDATION: Allowed Extensions
    // ---------------------------
    public class AllowedExtensions : ValidationAttribute
    {
        private readonly string[] _extensions;

        public AllowedExtensions(string[] extensions)
        {
            _extensions = extensions;
        }

        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if (value is IFormFile file)
            {
                var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
                if (!_extensions.Contains(extension))
                {
                    return new ValidationResult($"Invalid file type. Allowed types: {string.Join(", ", _extensions)}");
                }
            }
            return ValidationResult.Success;
        }
    }

    // ---------------------------
    // 📌 CUSTOM VALIDATION: Max File Size
    // ---------------------------
    public class MaxFileSize : ValidationAttribute
    {
        private readonly int _maxSize;

        public MaxFileSize(int maxSize)
        {
            _maxSize = maxSize;
        }

        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if (value is IFormFile file)
            {
                if (file.Length > _maxSize)
                {
                    return new ValidationResult($"Maximum allowed file size is {_maxSize / (1024 * 1024)} MB.");
                }
            }

            return ValidationResult.Success;
        }
    }
}
