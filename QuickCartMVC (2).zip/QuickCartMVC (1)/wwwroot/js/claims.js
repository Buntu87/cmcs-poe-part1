﻿/* claims.js
   jQuery helpers for QuickCartMVC Claims CRUD
   - Requires jQuery 3.x
   - Optional: bootstrap for modal/alerts styling
*/

(function ($) {
    "use strict";

    // Configuration
    var config = {
        urls: {
            loadAll: '/Claims/LoadAll',            // returns HTML fragment or full view
            create: '/Claims/Create',              // POST endpoint
            editGet: '/Claims/Edit/',              // append id for GET form: /Claims/Edit/5
            editPost: '/Claims/Edit/',             // append id for POST
            deletePost: '/Claims/DeleteConfirmed'  // POST expects form-data { id }
        },
        selectors: {
            container: '#claimsContainer',
            alerts: '#alerts',
            createForm: '#createForm', // optional; form for create
            ajaxForm: '#ajaxForm',     // generic id used when loading forms into modal
            modal: '#ajaxModal'        // optional modal id
        }
    };

    // Utility: show alert (bootstrap-style)
    function showAlert(message, type, timeoutMs) {
        type = type || 'success'; // success, danger, warning, info
        var alert = $('<div role="alert" class="alert alert-' + type + ' alert-dismissible fade show" />')
            .html(message)
            .append('<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>');

        $(config.selectors.alerts).append(alert);

        if (timeoutMs && timeoutMs > 0) {
            setTimeout(function () {
                alert.alert('close');
            }, timeoutMs);
        }
    }

    // Utility: get anti-forgery token from a form or meta tag
    function getAntiForgeryToken($form) {
        var token = null;
        if ($form && $form.length) {
            var $t = $form.find('input[name="__RequestVerificationToken"]');
            if ($t.length) token = $t.val();
        }
        if (!token) {
            // fallback to meta tag (if you add it to layout)
            var meta = $('meta[name="csrf-token"]');
            if (meta.length) token = meta.attr('content');
        }
        return token;
    }

    // Attach antiforgery token header for AJAX
    function attachAntiForgery(xhr, token) {
        if (token) xhr.setRequestHeader('RequestVerificationToken', token);
    }

    // Load claims HTML into container
    function loadClaims() {
        var $c = $(config.selectors.container);
        if (!$c.length) return;

        // show spinner
        $c.html('<div class="text-center p-4">Loading…</div>');

        $.get(config.urls.loadAll)
            .done(function (html) {
                // server might return a full view or a partial; inject it
                $c.html(html);
                bindUiButtons(); // re-bind buttons inside loaded HTML
            })
            .fail(function () {
                $c.html('<div class="text-danger p-4">Failed to load claims. Please refresh the page.</div>');
            });
    }

    // Generic AJAX form submit (supports file upload via FormData)
    function submitFormAjax($form, options) {
        options = options || {};
        var url = $form.attr('action') || window.location.href;
        var method = ($form.attr('method') || 'post').toUpperCase();

        var formData = new FormData($form[0]);

        var token = getAntiForgeryToken($form);

        // UI: disable submit buttons
        var $submit = $form.find('[type="submit"]');
        $submit.prop('disabled', true);

        $.ajax({
            url: url,
            type: method,
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function (xhr) {
                attachAntiForgery(xhr, token);
            }
        }).done(function (response, status, xhr) {
            // If server returned JSON with success flag, handle that:
            var contentType = xhr.getResponseHeader('Content-Type') || '';

            if (contentType.indexOf('application/json') !== -1) {
                try {
                    var json = (typeof response === 'string') ? JSON.parse(response) : response;
                    if (json && json.success) {
                        if (json.message) showAlert(json.message, 'success', 4000);
                        if (options.onSuccess) options.onSuccess(json);
                        loadClaims();
                        if ($(config.selectors.modal).length) {
                            // hide modal (bootstrap 5)
                            var modalEl = document.querySelector(config.selectors.modal);
                            if (modalEl) {
                                var modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                                modal.hide();
                            }
                        }
                    } else {
                        var err = (json && json.message) ? json.message : 'Server returned error';
                        showAlert(err, 'danger');
                        if (options.onError) options.onError(json);
                    }
                } catch (ex) {
                    // JSON parse failed - just show raw response
                    showAlert('Operation completed. Reloading list.', 'info', 3000);
                    loadClaims();
                }
            } else {
                // Server returned HTML (likely a rendered view/partial). Replace modal body or form area.
                if ($(config.selectors.modal).length && $(config.selectors.modal).find('.modal-body').length) {
                    $(config.selectors.modal).find('.modal-body').html(response);
                    // re-enable validation and re-bind submit handler
                    bindAjaxForms();
                } else {
                    // fallback: replace container
                    $(config.selectors.container).html(response);
                    bindUiButtons();
                }
            }
        }).fail(function (xhr) {
            var msg = 'Request failed. ';
            if (xhr.responseJSON && xhr.responseJSON.message) msg += xhr.responseJSON.message;
            showAlert(msg, 'danger');
        }).always(function () {
            $submit.prop('disabled', false);
        });
    }

    // Bind forms with id #ajaxForm to submit via AJAX
    function bindAjaxForms() {
        // Use event delegation for dynamically loaded forms
        $(document).off('submit.claims.ajax').on('submit.claims.ajax', 'form#ajaxForm, form[data-ajax="true"]', function (e) {
            var $form = $(this);

            // If the form includes files or explicit data-ajax="true", submit via AJAX
            if ($form.find('input[type="file"]').length || $form.data('ajax') === true || $form.data('ajax') === "true") {
                e.preventDefault();

                // optionally validate
                if ($form.valid && !$form.valid()) {
                    return;
                }

                submitFormAjax($form, {
                    onSuccess: function () {
                        // optional hook
                    }
                });
            }
            // else let default submit proceed (server render fallback)
        });
    }

    // Bind Create/Edit/Delete buttons inside loaded HTML
    function bindUiButtons() {
        var $c = $(config.selectors.container);

        // Create form link/button: open modal with create form
        $c.find('.create-claim, .open-create').off('click.create').on('click.create', function (e) {
            e.preventDefault();
            var url = $(this).data('url') || config.urls.create; // prefer data-url
            openModalForUrl(url);
        });

        // Edit buttons (GET the edit form into modal)
        $c.find('.edit-claim, .open-edit').off('click.edit').on('click.edit', function (e) {
            e.preventDefault();
            var id = $(this).data('id');
            if (!id) return;
            openModalForUrl(config.urls.editGet + id);
        });

        // Delete buttons
        $c.find('.delete-claim, .btn-delete').off('click.delete').on('click.delete', function (e) {
            e.preventDefault();
            var id = $(this).data('id');
            if (!id) return;
            if (!confirm('Are you sure you want to delete this claim?')) return;

            // create simple formData with antiforgery token
            var token = $('input[name="__RequestVerificationToken"]').first().val();
            var fd = new FormData();
            fd.append('id', id);
            if (token) fd.append('__RequestVerificationToken', token);

            $.ajax({
                url: config.urls.deletePost,
                type: 'POST',
                data: fd,
                contentType: false,
                processData: false,
                cache: false
            }).done(function (resp, status, xhr) {
                var contentType = xhr.getResponseHeader('Content-Type') || '';
                if (contentType.indexOf('application/json') !== -1) {
                    var json = (typeof resp === 'string') ? JSON.parse(resp) : resp;
                    if (json && json.success) {
                        showAlert(json.message || 'Deleted', 'success', 3000);
                    } else {
                        showAlert(json.message || 'Delete failed', 'danger');
                    }
                } else {
                    showAlert('Deleted (server returned HTML).', 'success', 3000);
                }
                loadClaims();
            }).fail(function () {
                showAlert('Delete request failed', 'danger');
            });
        });

        // Ensure AJAX forms are bound
        bindAjaxForms();
    }

    // Open modal and load URL content into modal body (GET)
    function openModalForUrl(url) {
        if (!$(config.selectors.modal).length) {
            // No modal present in layout — do a full navigation
            window.location.href = url;
            return;
        }

        var $modal = $(config.selectors.modal);
        var $modalBody = $modal.find('.modal-body');
        $modalBody.html('<div class="text-center p-4">Loading…</div>');
        var modalInstance = bootstrap.Modal.getInstance($modal[0]) || new bootstrap.Modal($modal[0]);
        modalInstance.show();

        $.get(url)
            .done(function (html) {
                $modalBody.html(html);
                // after loading the form into the modal, re-bind AJAX form submit
                bindAjaxForms();
            })
            .fail(function () {
                $modalBody.html('<div class="text-danger p-3">Failed to load. Try refreshing the page.</div>');
            });
    }

    // Initialize on DOM ready
    $(function () {
        loadClaims();

        // If layout has global create button outside container
        $(document).on('click', '.global-create-claim', function (e) {
            e.preventDefault();
            openModalForUrl($(this).data('url') || config.urls.create);
        });

        // Bind forms already on page (non-dynamic)
        bindAjaxForms();
    });

    // expose some helpers if needed
    window.QuickCartClaims = {
        loadClaims: loadClaims,
        openModalForUrl: openModalForUrl,
        showAlert: showAlert
    };

})(jQuery);
