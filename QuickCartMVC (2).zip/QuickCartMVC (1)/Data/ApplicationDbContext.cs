using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using QuickCartMVC.Models;
using System.Data;

namespace QuickCartMVC.Data
{
    public class ApplicationDbContext : DbContext
    {
        private static IConfiguration? Configuration { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // ---------------------------------------------
        // Load connection string manually
        // ---------------------------------------------
        private string GetConnectionString()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            Configuration = builder.Build();
            return Configuration.GetConnectionString("QuickCartMVC");
        }

        // =============================================
        // STORED PROCEDURE: Get All Claim Items
        // =============================================
        public List<ClaimItem> GetAll()
        {
            List<ClaimItem> claimItemList = new List<ClaimItem>();

            using (SqlConnection conn = new SqlConnection(GetConnectionString()))
            using (SqlCommand cmd = new SqlCommand("sp_GetAllClaimItems", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    ClaimItem claimItem = new ClaimItem
                    {
                        Id = Convert.ToInt32(dr["Id"]),
                        Title = dr["Title"].ToString(),
                        Description = dr["Description"].ToString(),
                        Amount = Convert.ToDecimal(dr["Amount"]),
                        SubmittedOn = Convert.ToDateTime(dr["SubmittedOn"]),
                        Status = dr["Status"].ToString(),
                        FileName = dr["FileName"].ToString()
                    };

                    claimItemList.Add(claimItem);
                }
            }

            return claimItemList;
        }

        // =============================================
        // STORED PROCEDURE: Insert Claim Item
        // =============================================
        public bool Insert(ClaimItem model)
        {
            int rowsAffected = 0;

            using (SqlConnection conn = new SqlConnection(GetConnectionString()))
            using (SqlCommand cmd = new SqlCommand("sp_InsertClaimItem", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Title", model.Title);
                cmd.Parameters.AddWithValue("@Description", model.Description);
                cmd.Parameters.AddWithValue("@Amount", model.Amount);
                cmd.Parameters.AddWithValue("@SubmittedOn", model.SubmittedOn);
                cmd.Parameters.AddWithValue("@Status", model.Status);
                cmd.Parameters.AddWithValue("@FileName", (object?)model.FileName ?? DBNull.Value);

                conn.Open();
                rowsAffected = cmd.ExecuteNonQuery();
            }

            return rowsAffected > 0;
        }

        // ---------------------------------------------
        // EF Core Table Mapping
        // ---------------------------------------------
        public DbSet<ClaimItem> Claims { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ClaimItem>(entity =>
            {
                entity.ToTable("Claims");

                entity.Property(c => c.Title)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(c => c.Description)
                    .HasMaxLength(2000);

                entity.Property(c => c.Amount)
                    .HasColumnType("decimal(18,2)");

                entity.Property(c => c.Status)
                    .HasMaxLength(50)
                    .HasDefaultValue("Pending");

                entity.Property(c => c.SubmittedOn)
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(c => c.FileName)
                    .HasMaxLength(255)
                    .IsRequired(false);
            });
        }
    }
}

