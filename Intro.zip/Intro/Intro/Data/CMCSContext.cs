﻿// Import the namespace where the model (MonthlyClaim) is defined
using System.Collections.Generic;
using Intro.Models;


// Import Entity Framework Core functionality
using Microsoft.EntityFrameworkCore;

namespace Intro.Data
{
    // This class represents the database context, used to interact with the database
    public class CMCSContext : DbContext
    {
        // Constructor that receives configuration options (like the connection string)
        // and passes them to the base DbContext class
        public CMCSContext(DbContextOptions<CMCSContext> options)
            : base(options)
        {
        }

        // This DbSet represents the "MonthlyClaims" table in the database
        // You can use it to query or save MonthlyClaim records
        public DbSet<MonthlyClaim> MonthlyClaims { get; set; }
    }
}