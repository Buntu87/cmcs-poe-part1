﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.IO;
using Intro.Data;
using Intro.Models;
using Microsoft.AspNetCore.Hosting;

namespace Intro.Controllers
{
    public class MonthlyClaimsController : Controller
    {
        private readonly CMCSContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public MonthlyClaimsController(CMCSContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _webHostEnvironment = webHostEnvironment ?? throw new ArgumentNullException(nameof(webHostEnvironment));
        }

        // GET: MonthlyClaims
        public async Task<IActionResult> Index()
        {
            return View(await _context.MonthlyClaims.ToListAsync());
        }

        // GET: MonthlyClaims/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var monthlyClaim = await _context.MonthlyClaims
                .FirstOrDefaultAsync(m => m.Id == id);
            if (monthlyClaim == null)
            {
                return NotFound();
            }

            return View(monthlyClaim);
        }

        // GET: MonthlyClaims/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: MonthlyClaims/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(MonthlyClaim model, IFormFile uploadedFile)
        {
            if (ModelState.IsValid)
            {
                // Process file upload
                if (uploadedFile != null && uploadedFile.Length > 0)
                {
                    // Validate file type
                    var allowedExtensions = new[] { ".pdf", ".docx", ".xlsx", ".mp3", ".mp4" };
                    var extension = Path.GetExtension(uploadedFile.FileName).ToLower();

                    if (Array.Exists(allowedExtensions, e => e == extension))
                    {
                        // Save the file
                        var filePath = Path.Combine(_webHostEnvironment.WebRootPath, "uploads", uploadedFile.FileName); // Path in wwwroot/uploads/
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await uploadedFile.CopyToAsync(stream);
                        }

                        // Save the file path in the model
                        model.UploadedFilePath = Path.Combine("uploads", uploadedFile.FileName);
                    }
                    else
                    {
                        ModelState.AddModelError("UploadedFile", "Invalid file type.");
                    }
                }

                // Save claim to the database
                _context.Add(model);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index)); // Redirect to index or review page
            }

            return View(model); // Return the form with validation errors if any
        }

        // GET: MonthlyClaims/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var monthlyClaim = await _context.MonthlyClaims.FindAsync(id);
            if (monthlyClaim == null)
            {
                return NotFound();
            }
            return View(monthlyClaim);
        }

        // POST: MonthlyClaims/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,HoursWorked,HourlyRate,Notes,Status,UploadedFilePath")] MonthlyClaim monthlyClaim)
        {
            if (id != monthlyClaim.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(monthlyClaim);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MonthlyClaimExists(monthlyClaim.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(monthlyClaim);
        }

        private bool MonthlyClaimExists(int? id)
        {
            throw new NotImplementedException();
        }

        // GET: MonthlyClaims/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var monthlyClaim = await _context.MonthlyClaims
                .FirstOrDefaultAsync(m => m.Id == id);
            if (monthlyClaim == null)
            {
                return NotFound();
            }

            return View(monthlyClaim);
        }

        // POST: MonthlyClaims/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var monthlyClaim = await _context.MonthlyClaims.FindAsync(id);
            if (monthlyClaim != null)
            {
                _context.MonthlyClaims.Remove(monthlyClaim);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MonthlyClaimExists(int id)
        {
            return _context.MonthlyClaims.Any(e => e.Id == id);
        }

        // Approve action
        [HttpPost]
        public async Task<IActionResult> Approve(int id)
        {
            var claim = await _context.MonthlyClaims.FindAsync(id);
            if (claim == null)
            {
                return NotFound();
            }

            claim.Status = "Approved";
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Review));
        }

        // Reject action
        [HttpPost]
        public async Task<IActionResult> Reject(int id)
        {
            var claim = await _context.MonthlyClaims.FindAsync(id);
            if (claim == null)
            {
                return NotFound();
            }

            claim.Status = "Rejected";
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Review));
        }

        // GET: MonthlyClaims/Review
        public async Task<IActionResult> Review()
        {
            var pendingClaims = await _context.MonthlyClaims
                .Where(c => c.Status == "Pending")
                .ToListAsync();

            return View(pendingClaims);
        }
    }
}

