﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Intro.Models
{
    public class MonthlyClaim
    {
        public int? Id { get; set; }

        [Required]
        [Range(0, 24, ErrorMessage = "Please enter a valid number of hours worked (0-24).")]
        public int HoursWorked { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Hourly rate must be greater than zero.")]
        public decimal HourlyRate { get; set; }

        [StringLength(500, ErrorMessage = "Notes cannot be longer than 500 characters.")]
        public string? Notes { get; set; }  // Nullable as per the requirement

        [Required(ErrorMessage = "Status is required.")]
        public string Status { get; set; } = string.Empty;

        // File upload property
        [DataType(DataType.Upload)]
        public IFormFile? UploadedFile { get; set; }

        // This can be set manually once the file is uploaded
        public string? UploadedFilePath { get; set; }
    }
}
